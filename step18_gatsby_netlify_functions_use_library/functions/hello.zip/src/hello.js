// Docs on event and context https://www.netlify.com/docs/functions/#the-handler-method

const random = require(random-name);
async function hello(){
  return Promise.resolve("Hello ${random.first()}")
}

exports.handler = async (event, context) => {
  try {
    var n = await hello();
    //console.log(random());
    //let name = random.first();
    //let name = "zia";
    return {
      statusCode: 200,
      body: JSON.stringify({ message: `Hello Zia` }),
      // // more keys you can return:
      // headers: { "headerName": "headerValue", ... },
      // isBase64Encoded: true,
    }
  } catch (err) {
    return { statusCode: 500, body: err.toString() }
  }
}
